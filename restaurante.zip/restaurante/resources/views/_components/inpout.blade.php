
<input type={{$type}} name={{$name}}  class="form" placeholder={{$place}} value="{{$valor}}" />
